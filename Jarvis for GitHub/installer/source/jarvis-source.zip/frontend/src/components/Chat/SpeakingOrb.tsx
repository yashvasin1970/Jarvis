import { useEffect, useRef, useState } from 'react';
import { getSpeechLevel, useTtsStore } from '../../lib/tts';

/**
 * Local change (2026-11-08, the user's request): while Jarvis reads a reply aloud, a glowing
 * golden "hologram" orb fills the chat area and moves with the voice. Made richer the same
 * day, and the chat behind it (message box and text) is now hidden while he speaks.
 * The voice bar has the same design (GoldOrb in voice-popup\jarvis_voice.py).
 *
 * An original canvas animation: dotted globe lines, amber light fragments on tilted rings
 * turning in 3D, flickering "data blocks" that light up with the voice, a bright sweeping
 * swirl, a lens ring and turning arcs round the core, embers orbiting outside, a ripple on
 * each louder word, and sparks; it grows in when it appears. Everything follows the voice
 * level (getSpeechLevel), or pulses on its own if that can't be measured. Click/Esc = stop.
 */

type Ring = { r: number; tx: number; ty: number; sp: number };
type Dash = { ring: number; a0: number; len: number; w: number; fl: number };
type Block = { th: number; ph: number; r: number; len: number; w: number; fl: number; fq: number };
type Ember = { a: number; r: number; sp: number; fl: number; z: number };
type Spark = { x: number; y: number; vx: number; vy: number; life: number; max: number };

function makeScene() {
  const rnd = Math.random;
  const sign = () => (rnd() < 0.5 ? -1 : 1);
  const rings: Ring[] = Array.from({ length: 16 }, (_, i) => ({
    r: 0.28 + 0.72 * Math.sqrt(i / 15) * (0.93 + 0.07 * rnd()),
    tx: (rnd() - 0.5) * Math.PI, ty: (rnd() - 0.5) * Math.PI, sp: (0.1 + rnd() * 0.45) * sign(),
  }));
  const dashes: Dash[] = [];
  rings.forEach((_, ring) => {
    const n = 16 + Math.floor(rnd() * 18);
    for (let k = 0; k < n; k++) {
      dashes.push({ ring, a0: rnd() * Math.PI * 2, len: 0.04 + rnd() * 0.42, w: 0.7 + rnd() * 1.9, fl: rnd() * 10 });
    }
  });
  const blocks: Block[] = Array.from({ length: 190 }, () => ({
    th: rnd() * Math.PI * 2, ph: Math.acos(2 * rnd() - 1), r: 0.55 + rnd() * 0.5,
    len: 0.025 + rnd() * 0.05, w: 1.6 + rnd() * 2.2, fl: rnd() * 10, fq: 1.5 + rnd() * 4,
  }));
  const embers: Ember[] = Array.from({ length: 60 }, () => ({
    a: rnd() * Math.PI * 2, r: 1.08 + rnd() * 0.24, sp: (0.05 + rnd() * 0.25) * sign(), fl: rnd() * 10, z: rnd(),
  }));
  return { rings, dashes, blocks, embers };
}

// Rotate a point around X, then Y; returns [x, y, z].
function rot(x: number, y: number, z: number, ax: number, ay: number): [number, number, number] {
  const cx = Math.cos(ax), sx = Math.sin(ax);
  const y1 = y * cx - z * sx, z1 = y * sx + z * cx;
  const cy = Math.cos(ay), sy = Math.sin(ay);
  return [x * cy + z1 * sy, y1, -x * sy + z1 * cy];
}

// Brightness 0..1 -> a colour on the amber -> gold -> white-hot ramp.
function gold(b: number, a: number): string {
  const t = Math.max(0, Math.min(1, b));
  const g = Math.round(110 + 135 * t), bl = Math.round(20 + 200 * t * t);
  return `rgba(255,${g},${bl},${Math.max(0, Math.min(1, a))})`;
}

export function SpeakingOrb() {
  const ttsState = useTtsStore((s) => s.state);
  const active = ttsState !== 'idle';
  const [mounted, setMounted] = useState(false);
  const [shown, setShown] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stateRef = useRef(ttsState);
  stateRef.current = ttsState;

  // Fade in when speech starts; fade out, then stop drawing, when it ends.
  useEffect(() => {
    if (active) {
      setMounted(true);
      const id = requestAnimationFrame(() => setShown(true));
      return () => cancelAnimationFrame(id);
    }
    setShown(false);
    const t = setTimeout(() => setMounted(false), 450);
    return () => clearTimeout(t);
  }, [active]);

  useEffect(() => {
    if (!active) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === 'Escape') useTtsStore.getState().stop(); };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [active]);

  useEffect(() => {
    if (!mounted) return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    const css = Math.round(Math.min(460, window.innerWidth * 0.66, window.innerHeight * 0.62));
    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    const px = Math.round(css * dpr);
    canvas.width = px; canvas.height = px;
    canvas.style.width = `${css}px`; canvas.style.height = `${css}px`;
    const buf = document.createElement('canvas');
    buf.width = px; buf.height = px;
    const b = buf.getContext('2d')!;
    const scene = makeScene();
    const sparks: Spark[] = [];
    let pulses: number[] = [];
    const calm = window.matchMedia?.('(prefers-reduced-motion: reduce)').matches ? 0.35 : 1;
    let level = 0, slow = 0, spin = 0, swirl = 0, lastPulse = 0, raf = 0;
    const born = performance.now();
    let last = born;

    const frame = (now: number) => {
      const dt = Math.min(0.05, (now - last) / 1000);
      last = now;
      const t = (now - born) / 1000;
      let grow = Math.min(1, t / 0.5);
      grow = 1 - (1 - grow) ** 3;                                   // ease-out grow-in
      const speaking = stateRef.current === 'speaking';
      const measured = speaking ? getSpeechLevel() : null;
      const target = !speaking ? 0.06 : measured ?? 0.32 + 0.22 * Math.sin(t * 7.3) * Math.sin(t * 2.1 + 1);
      level += (target - level) * (target > level ? 0.45 : 0.12);
      slow += (level - slow) * 0.05;
      const lv = level;
      if (speaking && lv - slow > 0.12 && now - lastPulse > 280) { pulses.push(now); lastPulse = now; }
      spin += dt * (0.22 + lv * 1.0) * calm;
      swirl += dt * (0.9 + lv * 3.0) * calm;

      const c = px / 2;
      const R = px * 0.34 * (0.78 + 0.22 * grow) * (1 + lv * 0.07);
      const gain = (0.5 + lv * 0.8) * (0.3 + 0.7 * grow);
      const P3 = (x: number, y: number, z: number, ax: number, ay: number): [number, number, number] => {
        const [rx, ry, rz] = rot(x, y, z, ax, ay);
        const p = 1 / (1.6 - rz * 0.35);
        return [c + rx * R * p * 1.6, c + ry * R * p * 1.6, rz];
      };
      b.globalCompositeOperation = 'source-over';
      b.clearRect(0, 0, px, px);
      b.globalCompositeOperation = 'lighter';
      b.lineCap = 'round';

      // Soft halo.
      let g = b.createRadialGradient(c, c, 0, c, c, R * 1.4);
      g.addColorStop(0, `rgba(255,160,50,${(0.07 + lv * 0.14) * grow})`);
      g.addColorStop(1, 'rgba(255,120,20,0)');
      b.fillStyle = g; b.fillRect(0, 0, px, px);

      // Globe lines: dotted latitude bands.
      for (const lat of [-1, -0.5, 0, 0.5, 1]) {
        const y0 = Math.sin(lat), cr = Math.cos(lat);
        let prev: [number, number, number] | null = null;
        for (let k = 0; k <= 48; k++) {
          const a = (k / 48) * Math.PI * 2;
          const p = P3(Math.cos(a) * cr, y0, Math.sin(a) * cr, 0.38, spin * 0.7);
          if (prev && k % 2) {
            const depth = (p[2] + 1) / 2;
            b.strokeStyle = gold(0.3, (0.05 + depth * 0.16) * gain);
            b.lineWidth = dpr;
            b.beginPath(); b.moveTo(prev[0], prev[1]); b.lineTo(p[0], p[1]); b.stroke();
          }
          prev = p;
        }
      }

      // Light fragments on tilted rings (front = brighter).
      for (const d of scene.dashes) {
        const ring = scene.rings[d.ring];
        const a = d.a0 + spin * ring.sp * 3;
        const ax = ring.tx + spin * 0.3, ay = ring.ty + spin;
        b.beginPath();
        let zSum = 0;
        for (let s = 0; s <= 5; s++) {
          const ang = a + (d.len * s) / 5;
          const p = P3(Math.cos(ang) * ring.r, Math.sin(ang) * ring.r, 0, ax, ay);
          zSum += p[2];
          if (s === 0) b.moveTo(p[0], p[1]); else b.lineTo(p[0], p[1]);
        }
        const depth = (zSum / 6 + 1) / 2;
        const fl = 0.75 + 0.25 * Math.sin(t * 6 + d.fl * 7);
        b.strokeStyle = gold(0.25 + depth * 0.6, (0.15 + depth * 0.75) * gain * fl);
        b.lineWidth = d.w * dpr * (0.55 + depth * 0.75);
        b.stroke();
      }

      // Data blocks: short thick bars on the shells that flicker on with the voice.
      b.lineCap = 'butt';
      for (const k of scene.blocks) {
        if (Math.sin(t * k.fq + k.fl * 9) < 0.35 - lv * 1.2) continue;
        const sp = Math.sin(k.ph), x0 = sp * Math.cos(k.th) * k.r, y0 = Math.cos(k.ph) * k.r, z0 = sp * Math.sin(k.th) * k.r;
        const tx = -Math.sin(k.th) * k.len, tz = Math.cos(k.th) * k.len;
        const p0 = P3(x0 - tx, y0, z0 - tz, 0.38, spin * 0.7), p1 = P3(x0 + tx, y0, z0 + tz, 0.38, spin * 0.7);
        const depth = (p0[2] + 1) / 2;
        b.strokeStyle = gold(0.35 + depth * 0.55, (0.15 + depth * 0.8) * gain);
        b.lineWidth = k.w * dpr * (0.5 + depth * 0.6);
        b.beginPath(); b.moveTo(p0[0], p0[1]); b.lineTo(p1[0], p1[1]); b.stroke();
      }
      b.lineCap = 'round';

      // The swirl: bright, tapering arcs sweeping round on tilted rings.
      const swirls: [number, number, number][] = [[0.95, 1, 1.9], [-0.6, -1, 1.2]];
      swirls.forEach(([tilt, dir, len], k) => {
        const a0 = swirl * dir * (1 + k * 0.35);
        let prev: [number, number, number] | null = null;
        for (let j = 0; j <= 20; j++) {
          const a = a0 - (len * j) / 20;
          const p = P3(Math.cos(a) * 0.62, Math.sin(a) * 0.62 * 0.92, 0, tilt, 0.3 + k);
          if (prev) {
            const f = 1 - j / 21;
            b.strokeStyle = gold(0.6 + 0.4 * f, (0.35 + 0.65 * f) * gain * (1 - k * 0.3));
            b.lineWidth = (1 + 5.5 * f) * dpr * (1 + lv * 0.6) * (1 - k * 0.35);
            b.beginPath(); b.moveTo(prev[0], prev[1]); b.lineTo(p[0], p[1]); b.stroke();
          }
          prev = p;
        }
      });

      // Lens ring and turning arcs round the core.
      b.strokeStyle = gold(0.8, 0.55 * gain + 0.15);
      b.lineWidth = 1.4 * dpr;
      b.beginPath(); b.arc(c, c, R * 0.17, 0, Math.PI * 2); b.stroke();
      [0.25, 0.31].forEach((rr, k) => {
        const st = swirl * (k ? 1.6 : -1.2);
        b.strokeStyle = gold(0.6, (0.35 + lv * 0.45) * (0.4 + 0.6 * grow));
        b.lineWidth = (1.8 - k * 0.6) * dpr;
        for (let q = 0; q < 3; q++) {
          b.beginPath(); b.arc(c, c, R * rr, st + (q * 2 * Math.PI) / 3, st + (q * 2 * Math.PI) / 3 + 1.2); b.stroke();
        }
      });

      // Ripples on louder words.
      pulses = pulses.filter((p0) => now - p0 < 900);
      for (const p0 of pulses) {
        const age = (now - p0) / 900;
        b.strokeStyle = gold(0.7, 0.6 * (1 - age) ** 1.5);
        b.lineWidth = (2.2 * (1 - age) + 0.6) * dpr;
        b.beginPath(); b.arc(c, c, R * (0.35 + age), 0, Math.PI * 2); b.stroke();
      }

      // Embers orbiting the outside.
      for (const e of scene.embers) {
        const a = e.a + t * e.sp * calm;
        const rr = R * e.r * (1 + 0.04 * Math.sin(t * 2 + e.fl));
        const on = 0.5 + 0.5 * Math.sin(t * 4 + e.fl * 5);
        b.fillStyle = gold(0.5 + 0.5 * on, (0.25 + 0.65 * on) * gain);
        b.beginPath();
        b.arc(c + Math.cos(a) * rr, c + Math.sin(a) * rr * (0.55 + 0.45 * e.z), dpr * (0.8 + 1.4 * on * e.z), 0, Math.PI * 2);
        b.fill();
      }

      // Sparks thrown off when the voice is loud.
      const emit = speaking ? lv * 7 * calm : 0;
      for (let i = 0; i < emit; i++) {
        if (Math.random() > emit - i) break;
        const ang = Math.random() * Math.PI * 2, rr = R * (0.85 + Math.random() * 0.2);
        const v = (0.5 + Math.random() * 1.8) * dpr * (0.6 + lv);
        sparks.push({ x: c + Math.cos(ang) * rr, y: c + Math.sin(ang) * rr, vx: Math.cos(ang) * v, vy: Math.sin(ang) * v,
          life: 0, max: 22 + Math.random() * 40 });
      }
      for (let i = sparks.length - 1; i >= 0; i--) {
        const s = sparks[i];
        s.life += 1; s.x += s.vx; s.y += s.vy; s.vx *= 0.985; s.vy *= 0.985;
        if (s.life > s.max) { sparks.splice(i, 1); continue; }
        const a = 1 - s.life / s.max;
        b.strokeStyle = gold(0.8, a * 0.9);
        b.lineWidth = 1.2 * dpr;
        b.beginPath(); b.moveTo(s.x, s.y); b.lineTo(s.x - s.vx * 3, s.y - s.vy * 3); b.stroke();
      }

      // Core.
      const core = R * (0.06 + lv * 0.06);
      g = b.createRadialGradient(c, c, 0, c, c, core * 2.4);
      g.addColorStop(0, `rgba(255,250,232,${0.95 * grow})`);
      g.addColorStop(0.3, `rgba(255,205,110,${0.7 * grow})`);
      g.addColorStop(1, 'rgba(255,140,30,0)');
      b.fillStyle = g; b.beginPath(); b.arc(c, c, core * 2.4, 0, Math.PI * 2); b.fill();

      // Glow: blurred copies of the scene under a sharp one.
      ctx.globalCompositeOperation = 'source-over';
      ctx.clearRect(0, 0, px, px);
      ctx.globalCompositeOperation = 'lighter';
      ctx.globalAlpha = 0.7;
      ctx.filter = `blur(${Math.round(9 * dpr)}px)`; ctx.drawImage(buf, 0, 0);
      ctx.globalAlpha = 0.9;
      ctx.filter = `blur(${Math.round(2.5 * dpr)}px)`; ctx.drawImage(buf, 0, 0);
      ctx.globalAlpha = 1;
      ctx.filter = 'none'; ctx.drawImage(buf, 0, 0);
      raf = requestAnimationFrame(frame);
    };
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, [mounted]);

  if (!mounted) return null;
  return (
    <div
      onClick={() => useTtsStore.getState().stop()}
      title="Click to stop"
      className="absolute inset-0 z-30 flex flex-col items-center justify-center cursor-pointer select-none"
      style={{
        // Solid, so the chat text and message box are hidden while Jarvis speaks.
        background: 'radial-gradient(circle at 50% 46%, rgb(20,14,26), rgb(10,8,14) 70%)',
        opacity: shown ? 1 : 0,
        transition: 'opacity 400ms ease',
      }}
    >
      <canvas ref={canvasRef} aria-hidden="true" />
      <div className="mt-2 text-[10px] tracking-[0.3em] uppercase" style={{ color: 'rgba(255,196,110,0.45)' }}>
        Click or press Esc to stop
      </div>
    </div>
  );
}
