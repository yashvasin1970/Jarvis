import { ChatArea } from '../components/Chat/ChatArea';

// Local change: the System panel (session, device, cost comparison,
// leaderboard) lives in Settings > System instead of a right-hand column.
export function ChatPage() {
  return (
    <div className="flex h-full overflow-hidden">
      <div className="flex-1 min-w-0">
        <ChatArea />
      </div>
    </div>
  );
}
